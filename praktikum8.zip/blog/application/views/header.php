<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Praktikum 08</title>
</head>
<body>
    <header role="banner">
        <h2>Praktikum 8 - STTNF</h2>
        <a href="#">Home</a> | <a href="#">Activity</a> | <a href="#">My Score</a> | <a href="#">Login</a>
    </header>
</body>
</html>