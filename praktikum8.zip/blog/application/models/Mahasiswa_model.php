<?php

//buat class
class Mahasiswa_model extends CI_Model{
    //Struktur Data
    public $id, $nama, $nim, $gender, $tmp_lahir, $tgl_lahir, $ipk;

    //Method
    public function predikat(){
        $predikat = ($this->ipk >=3.75) ? "Cumlaude" : "Bagus";
        return $predikat;
    }
}
?>