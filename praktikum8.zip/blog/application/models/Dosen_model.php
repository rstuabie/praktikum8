<?php

//buat class
class Dosen_model extends CI_Model{
    //Struktur Data
    public $id, $nama, $nim, $gender, $tmp_lahir, $tgl_lahir, $ipk;

}
?>