<?php

//buat class
class Matakuliah_model extends CI_Model{
    //Struktur Data
    public $nama, $sks, $kode;
    
}
?>